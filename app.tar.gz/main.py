import flet as ft
from tools.setup import main

ft.app(target=main)
