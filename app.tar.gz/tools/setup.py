import flet as ft

from . components.validations import *
from . components.constants   import *

class Message:
    def generate(self, title="", content="", actions=[], openMessage=False):
        return ft.AlertDialog(
            open              = openMessage,
            modal             = True,
            title             = ft.Text(title, text_align=ft.TextAlign.CENTER),
            content           = ft.Text(content, text_align=ft.TextAlign.CENTER),
            actions           = actions,
            actions_alignment = ft.MainAxisAlignment.CENTER
        )
        

def main(page: ft.Page):    
    page.vertical_alignment = ft.MainAxisAlignment.CENTER
    page.window_center()
    page.title = f"{TITLE} - {VERSION}"

    def constructMessageDownloadStatus(title="", content="", actions=[]):
        messageStatusDownload.title             = ft.Text(title, text_align=ft.TextAlign.CENTER)
        messageStatusDownload.content           = ft.Text(content, text_align=ft.TextAlign.CENTER)
        messageStatusDownload.actions           = actions
        messageStatusDownload.actions_alignment = ft.MainAxisAlignment.CENTER

        page.update()


    def submeteDownload(e):
        inputBoxUrl.error_text = None
        inputBoxUrl.focus()

        if not radioGroupTypeObject.value or not inputBoxUrl.value:
            inputBoxUrl.error_text = DATA_INVALID_INFORMATION

        elif not Validation().urlYouTube(inputBoxUrl.value):
            messageErrorUrlInvalid.open = True
            page.dialog = messageErrorUrlInvalid

        else:
            messageStatusDownload.open = True
            page.dialog = messageStatusDownload

            constructMessageDownloadStatus(MESSAGE_TITLE_DQWNLOAD_PROCESSING, MESSAGE_CONTENT_DOWNLOAD_PROCESSING, [ft.ProgressRing()])

            if Validation().downloadYoutube(inputBoxUrl.value, radioGroupTypeObject.value):
                constructMessageDownloadStatus(MESSAGE_TITLE_ALERT_DOWNLOAD_CONFIRMED, MESSAGE_CONTENT_ALERT_DOWNLOAD_CONFIRMED, actions)
                radioGroupTypeObject.value = ""
                inputBoxUrl.value = ""

            else:
                constructMessageDownloadStatus(MESSAGE_TITLE_ALERT_DOWNLOAD_NOT_CONFIRMED, MESSAGE_CONTENT_ALERT_DOWNLOAD_NOT_CONFIRMED, actions)

        page.update()


    def closeMessage(e):
        page.dialog.open = False
        page.update()


    actions = [
        ft.IconButton(ft.icons.CLOSE, on_click=closeMessage)
    ]
    
    messageTitle = ft.Text(TITLE, text_align=ft.TextAlign.CENTER, size=50)
    inputBoxUrl  = ft.TextField(hint_text=HINT_TEXT_INPUT_BOX, width=500, text_align=ft.TextAlign.CENTER)

    radioGroupTypeObject = ft.RadioGroup(content=ft.Row([
        ft.Radio(value=RADIO_VALUE_VIDEO, label=RADIO_LABEL_VIDEO),
        ft.Radio(value=RADIO_VALUE_AUDIO, label=RADIO_LABEL_AUDIO)
    ]))

    buttonSubmitDownload = ft.ElevatedButton(BUTTON_DOWNLOAD, on_click=submeteDownload)

    messageErrorUrlInvalid = Message().generate(MESSAGE_TITLE_ALERT_INVALID_URL, MESSAGE_CONTENT_ALERT_INVALID_URL, actions)

    messageStatusDownload = ft.AlertDialog(modal=True)

    page.add(
        ft.Row(
            [messageTitle], 
            alignment=ft.MainAxisAlignment.CENTER
        ),

        ft.Row(
            [inputBoxUrl], 
            alignment=ft.MainAxisAlignment.CENTER
        ),

        ft.Row(
            [radioGroupTypeObject], 
            alignment=ft.MainAxisAlignment.CENTER
        ),

        ft.Row(
            [buttonSubmitDownload], 
            alignment=ft.MainAxisAlignment.CENTER
        )
    )
